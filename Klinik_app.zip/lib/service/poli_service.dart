// lib/services/poli_service.dart

import 'package:dio/dio.dart';
import '../helpers/api_client.dart';
import '../model/poli.dart';

class PoliService {
  // Mengambil semua data poli
  Future<List<Poli>> listData() async {
    final Response response = await ApiClient().get('poli');
    final List data = response.data as List;
    List<Poli> result = data.map((json) => Poli.fromJson(json)).toList();
    return result;
  }

  // Menyimpan data poli baru
  Future<Poli> simpan(Poli poli) async {
    final data = poli.toJson();
    final Response response = await ApiClient().post('poli', data);
    return Poli.fromJson(response.data);
  }

  // Mengubah data poli yang sudah ada
  Future<Poli> ubah(Poli poli, String id) async {
    final data = poli.toJson();
    final Response response = await ApiClient().put('poli/$id', data);
    return Poli.fromJson(response.data);
  }

  // Mengambil satu data poli berdasarkan ID
  Future<Poli> getById(String id) async {
    final Response response = await ApiClient().get('poli/$id');
    return Poli.fromJson(response.data);
  }

  // Menghapus data poli
  Future<bool> hapus(String id) async {
    try {
      await ApiClient().delete('poli/$id');
      return true; // Berhasil hapus
    } catch (e) {
      return false; // Gagal hapus
    }
  }
}

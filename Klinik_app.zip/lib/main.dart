import 'package:flutter/material.dart';
import '/helpers/user_info.dart';
import '/ui/beranda.dart';
import '/ui/login.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var token = await UserInfo().getToken();
  print(token);

  // --- KODE SETELAH DIUBAH ---
  runApp(
    MaterialApp(
      title: "Klinik APP",
      debugShowCheckedModeBanner: false,
      home: Login(), // <-- UBAH MENJADI INI
    ),
  );
}

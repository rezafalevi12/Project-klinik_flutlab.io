import 'package:flutter/material.dart';
import '../ui/beranda.dart';
import '../ui/login.dart';
import '../ui/poli_page.dart';
import '../ui/pegawai_page.dart';

class Sidebar extends StatelessWidget {
  const Sidebar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // --- Header Sidebar dengan Warna Tema ---
          UserAccountsDrawerHeader(
            // Menambahkan dekorasi gradien yang sama dengan Beranda
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.teal.shade400, Colors.cyan.shade400],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            // Menambahkan gambar profil placeholder
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(
                Icons.person,
                size: 40,
                color: Colors.teal,
              ),
            ),
            accountName: const Text(
              "Admin",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            accountEmail: const Text(
              "admin@admin.com",
              style: TextStyle(
                color: Colors.white70,
              ),
            ),
          ),

          // --- Daftar Menu ---
          ListTile(
            leading: Icon(Icons.home, color: Colors.teal.shade700),
            title: const Text(
              "Beranda",
              style: TextStyle(color: Colors.black87),
            ),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const Beranda()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.local_hospital,
                color: Colors.teal.shade700), // Ikon disesuaikan
            title: const Text(
              "Poli",
              style: TextStyle(color: Colors.black87),
            ),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const PoliPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.people, color: Colors.teal.shade700),
            title: const Text(
              "Pegawai",
              style: TextStyle(color: Colors.black87),
            ),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const PegawaiPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.account_box_sharp, color: Colors.teal.shade700),
            title: const Text(
              "Pasien",
              style: TextStyle(color: Colors.black87),
            ),
            onTap: () {
              // TODO: Tambahkan navigasi ke halaman Pasien
              Navigator.pop(context); // Tutup sidebar dulu
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Fitur Pasien belum tersedia')),
              );
            },
          ),

          // --- Pembatas ---
          const Divider(height: 20, thickness: 1),

          // --- Tombol Keluar ---
          ListTile(
            leading: Icon(Icons.logout_rounded, color: Colors.red.shade600),
            title: Text(
              "Keluar",
              style: TextStyle(
                color: Colors.red.shade600,
                fontWeight: FontWeight.bold,
              ),
            ),
            onTap: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const Login()),
                (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}

// lib/helpers/api_client.dart (VERSI YANG SUDAH DIPERBAIKI)

import 'package:dio/dio.dart';

// Membuat instance Dio di dalam class agar lebih terenkapsulasi
class ApiClient {
  final Dio _dio;

  ApiClient()
      : _dio = Dio(BaseOptions(
          baseUrl: 'https://691c0a4a3aaeed735c8f3e7a.mockapi.io/',
          connectTimeout: const Duration(seconds: 5),
          receiveTimeout: const Duration(seconds: 3),
        ));

  Future<Response> get(String path) async {
    try {
      final response = await _dio.get(path); // Dio otomatis menghandle encoding
      return response;
    } on DioException catch (e) {
      // <-- PERBAIKAN DI SINI
      // Kamu bisa memberikan pesan error yang lebih spesifik
      throw Exception('Gagal mengambil data: ${e.message}');
    }
  }

  Future<Response> post(String path, dynamic data) async {
    try {
      final response = await _dio.post(path, data: data);
      return response;
    } on DioException catch (e) {
      // <-- PERBAIKAN DI SINI
      throw Exception('Gagal menyimpan data: ${e.message}');
    }
  }

  Future<Response> put(String path, dynamic data) async {
    try {
      final response = await _dio.put(path, data: data);
      return response;
    } on DioException catch (e) {
      // <-- PERBAIKAN DI SINI
      throw Exception('Gagal mengubah data: ${e.message}');
    }
  }

  Future<Response> delete(String path) async {
    try {
      final response = await _dio.delete(path);
      return response;
    } on DioException catch (e) {
      // <-- PERBAIKAN DI SINI
      throw Exception('Gagal menghapus data: ${e.message}');
    }
  }
}

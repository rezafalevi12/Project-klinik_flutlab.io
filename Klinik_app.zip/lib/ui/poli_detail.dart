import 'package:flutter/material.dart';
import '../model/poli.dart';
import '../service/poli_service.dart'; // Import service Anda
import 'poli_update_form.dart'; // Import form ubah
import 'poli_page.dart'; // Import halaman daftar

class PoliDetail extends StatelessWidget {
  final Poli poli;
  const PoliDetail({Key? key, required this.poli}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Poli"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Nama Poli",
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              poli.namaPoli,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Spacer(), // Mendorong tombol ke bawah
            Row(
              children: [
                // Tombol untuk Ubah
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.edit),
                    label: const Text("Ubah"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PoliUpdateForm(poli: poli),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                // Tombol untuk Hapus
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    icon: const Icon(Icons.delete),
                    label: const Text("Hapus"),
                    onPressed: () {
                      // Tampilkan dialog konfirmasi sebelum menghapus
                      _showDeleteConfirmation(context);
                    },
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Konfirmasi Hapus"),
          content:
              Text("Apakah Anda yakin ingin menghapus '${poli.namaPoli}'?"),
          actions: [
            TextButton(
              child: const Text("Batal"),
              onPressed: () {
                Navigator.of(context).pop(); // Tutup dialog
              },
            ),
            TextButton(
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              child: const Text("Hapus"),
              onPressed: () async {
                Navigator.of(context).pop(); // Tutup dialog

                // --- PERBAIKAN DAN PENAMBAHAN DI SINI ---
                try {
                  // Panggil fungsi 'hapus' dari service Anda
                  bool success = await PoliService().hapus(poli.id!);

                  if (success) {
                    // Jika berhasil, kembali ke halaman daftar
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => const PoliPage()),
                      (Route<dynamic> route) => false,
                    );

                    // Tampilkan pesan sukses
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Data Poli berhasil dihapus."),
                        backgroundColor: Colors.green,
                      ),
                    );
                  } else {
                    // Jika gagal, tampilkan pesan error
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Gagal menghapus data."),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                } catch (e) {
                  // Tangkap error lainnya
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Terjadi kesalahan: $e"),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import '../model/pasien.dart';
import 'pasien_detail.dart';

class PasienPage extends StatelessWidget {
  const PasienPage({super.key});

  @override
  Widget build(BuildContext context) {
    List<Pasien> listPasien = [
      Pasien(
          nomorRm: "RM001",
          nama: "Dewi Lestari",
          tanggalLahir: "1995-06-01",
          nomorTelepon: "081312345678",
          alamat: "Jl. Merdeka No. 12"),
      Pasien(
          nomorRm: "RM002",
          nama: "Rahmat Hidayat",
          tanggalLahir: "1992-09-17",
          nomorTelepon: "081398765432",
          alamat: "Jl. Sudirman No. 45"),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Data Pasien")),
      body: ListView.builder(
        itemCount: listPasien.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            child: Card(
              child: ListTile(
                title: Text(listPasien[index].nama),
                subtitle: Text("No RM: ${listPasien[index].nomorRm}"),
              ),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PasienDetail(pasien: listPasien[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

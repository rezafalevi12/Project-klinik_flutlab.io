import 'package:flutter/material.dart';
import '../widget/sidebar.dart'; // Pastikan path ini benar

// --- TAMBAHKAN IMPORT INI ---
// Import halaman Pegawai agar bisa dinavigasi
import 'pegawai_page.dart';
import 'poli_page.dart'; // Import untuk halaman Poli

class Beranda extends StatelessWidget {
  const Beranda({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Sidebar(),
      appBar: AppBar(
        title: const Text(
          "Beranda",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20.0),
        children: [
          _buildWelcomeCard(),
          const SizedBox(height: 30),
          _buildQuickActions(context),
        ],
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(24.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          gradient: LinearGradient(
            colors: [Colors.teal.shade400, Colors.cyan.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Halo, Selamat Datang!",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Apa yang ingin Anda lakukan hari ini?",
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Aksi Cepat",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 16),

        // Menggunakan Wrap agar tombol bisa pindah baris jika layar sempit
        Wrap(
          spacing: 12, // Jarak horizontal antar tombol
          runSpacing: 12, // Jarak vertikal antar baris
          alignment: WrapAlignment.spaceBetween,
          children: [
            // Tombol Data Poli
            _buildActionButton(
              context,
              icon: Icons.local_hospital,
              label: "Data Poli",
              color: Colors.red,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PoliPage()),
                );
              },
            ),
            // --- TOMBOL PEGAWAI (DIUBAH DARI "TAMBAH") ---
            _buildActionButton(
              context,
              icon: Icons.people, // Ikon yang lebih sesuai untuk pegawai
              label: "Pegawai", // Label diubah menjadi "Pegawai"
              color: Colors.indigo, // Warna yang berbeda
              // --- FUNGSI NAVIGASI KE HALAMAN PEGAWAI ---
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PegawaiPage()),
                );
              },
            ),
            // Tombol Lihat Data
            _buildActionButton(
              context,
              icon: Icons.list_alt,
              label: "Lihat Data",
              color: Colors.blue,
            ),
            // Tombol Pengaturan
            _buildActionButton(
              context,
              icon: Icons.settings,
              label: "Pengaturan",
              color: Colors.orange,
            ),
          ],
        ),
      ],
    );
  }

  // Widget helper untuk membangun setiap tombol aksi
  Widget _buildActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        // Lebar disesuaikan agar rapi di dalam Wrap
        width: (MediaQuery.of(context).size.width - 20 * 2 - 12 * 3) / 2,
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 30),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

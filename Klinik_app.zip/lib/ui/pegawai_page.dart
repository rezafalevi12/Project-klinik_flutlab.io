import 'package:flutter/material.dart';
import '../model/pegawai.dart';
import 'pegawai_detail.dart';

class PegawaiPage extends StatelessWidget {
  const PegawaiPage({super.key});

  @override
  Widget build(BuildContext context) {
    List<Pegawai> listPegawai = [
      Pegawai(
          nip: "PG001",
          nama: "Budi Santoso",
          tanggalLahir: "1985-03-12",
          nomorTelepon: "081234567890",
          email: "budi@mail.com",
          password: "12345"),
      Pegawai(
          nip: "PG002",
          nama: "Ani Wulandari",
          tanggalLahir: "1990-05-20",
          nomorTelepon: "081298765432",
          email: "ani@mail.com",
          password: "12345"),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Data Pegawai")),
      body: ListView.builder(
        itemCount: listPegawai.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            child: Card(
              child: ListTile(
                title: Text(listPegawai[index].nama),
                subtitle: Text("NIP: ${listPegawai[index].nip}"),
              ),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      PegawaiDetail(pegawai: listPegawai[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class Poli {
  String? id; // Tetap nullable, ini bagus untuk objek baru yang belum punya ID
  String namaPoli;

  Poli({this.id, required this.namaPoli});

  // Fungsi untuk membuat objek Poli dari data JSON (dari API/database)
  factory Poli.fromJson(Map<String, dynamic> json) {
    return Poli(
      id: json["id"] as String?, // Aman jika 'id' tidak ada
      namaPoli: json["nama_poli"] as String, // Asumsikan 'nama_poli' selalu ada
    );
  }

  // Fungsi untuk mengubah objek Poli ke dalam format JSON (untuk dikirim ke API/database)
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['nama_poli'] = this.namaPoli;
    // PERBAIKAN KRUSIAL: Tambahkan ID ke JSON jika tidak null
    if (this.id != null) {
      data['id'] = this.id;
    }
    return data;
  }
}

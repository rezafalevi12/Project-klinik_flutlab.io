import 'package:flutter/material.dart';
import '../models/inventory_item.dart';

class InventoryScreen extends StatelessWidget {
  final List<InventoryItem> inventoryItems;
  const InventoryScreen({super.key, required this.inventoryItems});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: inventoryItems.length,
      itemBuilder: (context, index) {
        final item = inventoryItems[index];
        final stockPercentage = item.currentStock / item.maxStock;
        final isLowStock = item.currentStock <= item.minStock;

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
          child: ListTile(
            leading: Icon(Icons.inventory,
                color: isLowStock ? Colors.red : Colors.grey),
            title: Text(item.name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: stockPercentage,
                  backgroundColor: Colors.grey[300],
                  valueColor: AlwaysStoppedAnimation<Color>(
                    isLowStock ? Colors.red : Colors.green,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                        '${item.currentStock} ${item.unit} / ${item.maxStock} ${item.unit}'),
                    if (isLowStock)
                      const Text('Stok Menipis!',
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// lib/screens/dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'home_screen.dart';
import 'menu_screen.dart';
import 'order_screen.dart';
import 'inventory_screen.dart';
import 'report_screen.dart';
import '../data/dummy_data.dart';
import 'profile_screen.dart'; // <-- IMPORT PROFILE SCREEN
import 'auth/login_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const HomeScreen(),
    const MenuScreen(),
    OrderScreen(orders: dummyOrders),
    InventoryScreen(inventoryItems: dummyInventoryItems),
    const ReportScreen(),
  ];

  final List<String> _appBarTitles = [
    'Dashboard Utama',
    'Manajemen Menu',
    'Daftar Pesanan',
    'Stok Bahan',
    'Laporan Penjualan',
  ];

  // Fungsi untuk menangani menu dari PopupMenuButton
  void _handleMenuAction(String action) {
    if (action == 'profile') {
      // Navigasi ke layar profil
      Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => const ProfileScreen()),
      );
    } else if (action == 'logout') {
      // Tampilkan dialog konfirmasi logout
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Konfirmasi Logout'),
          content: const Text('Apakah Anda yakin ingin keluar?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Tidak')),
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                  (Route<dynamic> route) => false,
                );
              },
              child: const Text('Ya'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // --- PERUBAHAN 1: Memberi Warna pada AppBar ---
      appBar: AppBar(
        title: Text(_appBarTitles[_currentIndex]),
        centerTitle: true,
        // Menambahkan warna latar belakang AppBar
        backgroundColor: Colors.indigo[0xffa95236],
        // Mengubah warna ikon dan teks di AppBar menjadi putih
        foregroundColor: Colors.white,
        elevation: 4, // Memberikan efek bayangan
        // --- PERUBAHAN: Gunakan PopupMenuButton ---
        actions: [
          PopupMenuButton<String>(
            iconColor: Colors.white, // Mengubah warna ikon menu titik-titik
            onSelected: _handleMenuAction,
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: 'profile',
                child: ListTile(
                  leading: Icon(Icons.person),
                  title: Text('Profil'),
                ),
              ),
              const PopupMenuItem<String>(
                value: 'logout',
                child: ListTile(
                  leading: Icon(Icons.logout),
                  title: Text('Logout'),
                ),
              ),
            ],
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      // --- PERUBAHAN 2: Memberi Warna pada BottomNavigationBar ---
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed, // Diperlukan untuk warna kustom
        // Mengubah warna latar belakang BottomNavigationBar
        backgroundColor: Color(0xffa95236),
        // Mengubah warna item yang dipilih
        selectedItemColor: Colors.white,
        // Mengubah warna item yang tidak dipilih
        unselectedItemColor: Colors.white70,
        // Mengubah warna label yang dipilih
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard), label: 'Dashboard'),
          BottomNavigationBarItem(
              icon: Icon(Icons.restaurant_menu), label: 'Menu'),
          BottomNavigationBarItem(
              icon: Icon(Icons.receipt_long), label: 'Pesanan'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory_2), label: 'Stok'),
          BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart), label: 'Laporan'),
        ],
      ),
    );
  }
}

// lib/screens/report_screen.dart

import 'package:flutter/material.dart';
import '../data/dummy_data.dart';

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key});

  void _showReportDialog(BuildContext context, String title) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          // Beri padding agar tidak mepet
          contentPadding: const EdgeInsets.all(16.0),
          // Gunakan SizedBox untuk memastikan dialog memiliki lebar yang cukup
          content: SizedBox(
            width: double.maxFinite, // Buat dialog selebar mungkin
            child: SingleChildScrollView(
              child: DataTable(
                // Tambahkan border agar tabel lebih rapi
                border: TableBorder.all(
                  color: Colors.grey[300]!,
                  width: 1,
                ),
                // Atur jarak antar kolom
                columnSpacing: 12,
                columns: const [
                  DataColumn(
                    label: Text('Menu',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  DataColumn(
                    label: Text('Terjual',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    // numeric: true akan membuat header dan konten rata kanan
                    numeric: true,
                  ),
                  DataColumn(
                    label: Text('Pendapatan',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    numeric: true,
                  ),
                ],
                rows: dummyMenuItems.map((item) {
                  // Data dummy untuk laporan
                  final soldCount =
                      [20, 15, 35, 50][dummyMenuItems.indexOf(item)];
                  final revenue = item.price * soldCount;
                  return DataRow(
                    cells: [
                      // --- PERBAIKAN UTAMA: Atur lebar dan overflow untuk nama menu ---
                      DataCell(
                        SizedBox(
                          // Berikan lebar maksimal untuk kolom menu
                          width: 180,
                          child: Text(
                            item.name,
                            // Jika teks terlalu panjang, tampilkan "..."
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                      DataCell(Text(soldCount.toString())),
                      DataCell(Text('Rp $revenue')),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
              backgroundColor: Colors.deepOrange,
              foregroundColor: Colors.white,
            ),
            onPressed: () =>
                _showReportDialog(context, 'Laporan Penjualan Harian'),
            icon: const Icon(Icons.today),
            label: const Text('Laporan Harian', style: TextStyle(fontSize: 18)),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
              backgroundColor: Colors.deepOrange,
              foregroundColor: Colors.white,
            ),
            onPressed: () =>
                _showReportDialog(context, 'Laporan Penjualan Mingguan'),
            icon: const Icon(Icons.date_range),
            label:
                const Text('Laporan Mingguan', style: TextStyle(fontSize: 18)),
          ),
        ],
      ),
    );
  }
}

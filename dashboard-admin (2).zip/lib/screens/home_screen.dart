// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Import provider
import '../providers/menu_provider.dart'; // Import provider kita

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Gunakan Consumer untuk mendengarkan perubahan di MenuProvider
    return Consumer<MenuProvider>(
      builder: (context, menuProvider, child) {
        final todaySales = 1500000;
        final todayOrders = 4; // Sementara
        final bestSellers =
            menuProvider.menuItems.take(3).toList(); // Ambil dari provider!

        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              Row(
                children: [
                  Expanded(
                      child: _buildStatCard(
                          'Total Penjualan',
                          'Rp ${todaySales.toString()}',
                          Icons.attach_money,
                          Colors.green)),
                  const SizedBox(width: 16),
                  Expanded(
                      child: _buildStatCard(
                          'Jumlah Pesanan',
                          todayOrders.toString(),
                          Icons.shopping_cart,
                          Colors.blue)),
                ],
              ),
              const SizedBox(height: 24),
              const Text('Menu Terlaris Hari Ini',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              ...bestSellers
                  .map((item) => Card(
                        child: ListTile(
                          leading: Image.network(item.imageUrl,
                              width: 50, height: 50, fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                            // Tambahkan error handling
                            return const Icon(Icons.broken_image,
                                color: Colors.grey);
                          }),
                          title: Text(item.name),
                          trailing: const Icon(Icons.trending_up,
                              color: Colors.green),
                        ),
                      ))
                  .toList(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatCard(
      String title, String value, IconData icon, Color color) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 10),
            Text(value,
                style: TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: color)),
            Text(title,
                style: const TextStyle(fontSize: 14, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

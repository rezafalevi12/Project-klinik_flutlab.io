import 'package:flutter/material.dart';
import '../models/order.dart';

class OrderScreen extends StatefulWidget {
  final List<Order> orders;
  const OrderScreen({super.key, required this.orders});

  @override
  State<OrderScreen> createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'diproses':
        return Colors.blue;
      case 'selesai':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  void _updateOrderStatus(String orderId, String newStatus) {
    setState(() {
      final order = widget.orders.firstWhere((o) => o.id == orderId);
      order.status = newStatus;
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Status pesanan $orderId diubah menjadi $newStatus')));
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: widget.orders.length,
      itemBuilder: (context, index) {
        final order = widget.orders[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(order.id,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    DropdownButton<String>(
                      value: order.status,
                      underline: Container(),
                      items: <String>['pending', 'diproses', 'selesai']
                          .map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value,
                              style: TextStyle(color: _getStatusColor(value))),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          _updateOrderStatus(order.id, newValue);
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text('Pelanggan: ${order.customerName}'),
                const SizedBox(height: 4),
                Text('Pesanan: ${order.items.join(', ')}'),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Text('Total: Rp ${order.total.toString()}',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}

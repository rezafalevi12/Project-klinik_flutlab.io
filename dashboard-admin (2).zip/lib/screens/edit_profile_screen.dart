// lib/screens/edit_profile_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/admin_model.dart';
import '../providers/admin_provider.dart';

class EditProfileScreen extends StatefulWidget {
  final AdminModel admin;

  const EditProfileScreen({super.key, required this.admin});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _phoneController;
  late TextEditingController _roleController;
  late TextEditingController _avatarController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.admin.name);
    _emailController = TextEditingController(text: widget.admin.email);
    _phoneController = TextEditingController(text: widget.admin.phoneNumber);
    _roleController = TextEditingController(text: widget.admin.role);
    _avatarController = TextEditingController(text: widget.admin.avatarUrl);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _roleController.dispose();
    _avatarController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    if (_formKey.currentState!.validate()) {
      final updatedAdmin = AdminModel(
        id: widget.admin.id,
        name: _nameController.text,
        email: _emailController.text,
        phoneNumber: _phoneController.text,
        role: _roleController.text,
        avatarUrl: _avatarController.text,
      );

      // Gunakan provider untuk mengupdate data
      Provider.of<AdminProvider>(context, listen: false)
          .updateAdmin(updatedAdmin);

      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Profil berhasil diperbarui!'),
            backgroundColor: Colors.green),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profil'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveProfile,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Center(
                child: CircleAvatar(
                  radius: 60,
                  backgroundImage: NetworkImage(_avatarController.text),
                  onBackgroundImageError: (exception, stackTrace) {
                    // Jika gambar error, tampilkan ikon default
                  },
                  child: _avatarController.text.isEmpty
                      ? const Icon(Icons.person, size: 60)
                      : null,
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                    labelText: 'Nama Lengkap', border: OutlineInputBorder()),
                validator: (value) =>
                    value!.isEmpty ? 'Nama tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                    labelText: 'Email', border: OutlineInputBorder()),
                validator: (value) =>
                    value!.isEmpty ? 'Email tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(
                    labelText: 'Nomor Telepon', border: OutlineInputBorder()),
                validator: (value) =>
                    value!.isEmpty ? 'Nomor telepon tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _roleController,
                decoration: const InputDecoration(
                    labelText: 'Jabatan/Role', border: OutlineInputBorder()),
                validator: (value) =>
                    value!.isEmpty ? 'Role tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _avatarController,
                decoration: const InputDecoration(
                    labelText: 'URL Avatar (opsional)',
                    border: OutlineInputBorder()),
                onChanged: (value) =>
                    setState(() {}), // Update UI saat URL berubah
              ),
            ],
          ),
        ),
      ),
    );
  }
}

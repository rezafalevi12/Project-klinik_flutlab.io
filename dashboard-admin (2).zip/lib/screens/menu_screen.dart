// lib/screens/menu_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/menu_item.dart';
import '../providers/menu_provider.dart';
import 'menu_form_screen.dart';

class MenuScreen extends StatelessWidget {
  // Tidak perlu StatefulWidget lagi
  const MenuScreen({super.key});

  Future<void> _navigateToForm(BuildContext context, {MenuItem? item}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => MenuFormScreen(item: item)),
    );

    if (result != null && result is MenuItem) {
      // Gunakan provider untuk menambah atau mengupdate
      if (item == null) {
        Provider.of<MenuProvider>(context, listen: false).addMenu(result);
      } else {
        Provider.of<MenuProvider>(context, listen: false).updateMenu(result);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MenuProvider>(
      builder: (context, menuProvider, child) {
        return Scaffold(
          floatingActionButton: FloatingActionButton(
            onPressed: () => _navigateToForm(context),
            backgroundColor: Colors.deepOrange,
            child: const Icon(Icons.add),
          ),
          body: ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: menuProvider.menuItems.length,
            itemBuilder: (context, index) {
              final item = menuProvider.menuItems[index];
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                child: ListTile(
                  leading: Image.network(item.imageUrl,
                      width: 60, height: 60, fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.broken_image, color: Colors.grey);
                  }),
                  title: Text(item.name,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Rp ${item.price.toString()}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Chip(
                        label: Text(item.isAvailable ? 'Tersedia' : 'Habis'),
                        backgroundColor: item.isAvailable
                            ? Colors.green[100]
                            : Colors.red[100],
                        labelStyle: TextStyle(
                          color: item.isAvailable
                              ? Colors.green[800]
                              : Colors.red[800],
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'edit') {
                            _navigateToForm(context, item: item);
                          } else if (value == 'delete') {
                            Provider.of<MenuProvider>(context, listen: false)
                                .deleteMenu(item.id);
                          } else if (value == 'toggle') {
                            Provider.of<MenuProvider>(context, listen: false)
                                .toggleAvailability(item.id);
                          }
                        },
                        itemBuilder: (context) => const [
                          PopupMenuItem(value: 'edit', child: Text('Edit')),
                          PopupMenuItem(value: 'delete', child: Text('Hapus')),
                          PopupMenuItem(
                              value: 'toggle',
                              child: Text('Ubah Ketersediaan')),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import '../services/admin_services.dart';
import '../models/admin_model.dart';

class AdminPage extends StatelessWidget {
  AdminPage({super.key});

  final AdminService service = AdminService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Admin'),
      ),

      // 👇 KODE KAMU MASUK DI SINI
      body: FutureBuilder<List<AdminModel>>(
        future: service.getAdmins(),
        builder: (context, snapshot) {
          // loading
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          // error
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          // data kosong
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('Belum ada admin'),
            );
          }

          final admins = snapshot.data!;

          return ListView.builder(
            itemCount: admins.length,
            itemBuilder: (context, i) {
              final admin = admins[i];

              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: admin.avatarUrl.isNotEmpty
                      ? NetworkImage(admin.avatarUrl)
                      : null,
                  child:
                      admin.avatarUrl.isEmpty ? const Icon(Icons.person) : null,
                ),
                title: Text(admin.name),
                subtitle: Text('${admin.role} • ${admin.email}'),
              );
            },
          );
        },
      ),
    );
  }
}

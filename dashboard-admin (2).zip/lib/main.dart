import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'providers/menu_provider.dart';
import 'providers/admin_provider.dart';
import 'screens/auth/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://qmtculntepnjamotobjg.supabase.co', // GANTI
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtdGN1bG50ZXBuamFtb3RvYmpnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxODI5NzAsImV4cCI6MjA4MDc1ODk3MH0.yNd4B8wq9WykRWjW7Cz0ngX8El_dqyAEUhXmWzRSV5A', // GANTI
  );

  runApp(const AdminRestaurantApp());
}

class AdminRestaurantApp extends StatelessWidget {
  const AdminRestaurantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => MenuProvider()..initializeMenu(),
        ),
        ChangeNotifierProvider(
          create: (_) => AdminProvider()..initializeAdmins(),
        ),
      ],
      child: MaterialApp(
        title: 'Dashboard Admin Restoran',
        theme: ThemeData(
          primarySwatch: Colors.deepOrange,
          scaffoldBackgroundColor: const Color(0xFFF5F5F5),
          cardColor: Colors.white,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.deepOrange,
            foregroundColor: Colors.white,
            elevation: 2,
          ),
        ),
        home: const LoginScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

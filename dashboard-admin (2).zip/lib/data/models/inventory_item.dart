class InventoryItem {
  final String id;
  final String name;
  final String unit;
  int currentStock;
  final int minStock;
  final int maxStock;

  InventoryItem({
    required this.id,
    required this.name,
    required this.unit,
    required this.currentStock,
    required this.minStock,
    required this.maxStock,
  });
}

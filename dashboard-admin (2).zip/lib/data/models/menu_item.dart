class MenuItem {
  final String id;
  final String name;
  final int price;
  final String imageUrl;
  bool isAvailable;

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    required this.imageUrl,
    this.isAvailable = true,
  });
}

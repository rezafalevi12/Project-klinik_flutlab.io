class Order {
  final String id;
  final String customerName;
  final List<String> items;
  String status; // pending, diproses, selesai
  final int total;

  Order({
    required this.id,
    required this.customerName,
    required this.items,
    required this.total,
    this.status = 'pending',
  });
}

import '../models/menu_item.dart';
import '../models/order.dart';
import '../models/inventory_item.dart';

final List<MenuItem> dummyMenuItems = [
  MenuItem(
      id: '1',
      name: 'Burger Ayam Crispy',
      price: 35000,
      imageUrl: 'https://i.ibb.co/L5fL2v2/burger.jpg'),
  MenuItem(
      id: '2',
      name: 'Kentang Goreng',
      price: 18000,
      imageUrl: 'https://i.ibb.co/68v8w2c/fries.jpg',
      isAvailable: false),
  MenuItem(
      id: '3',
      name: 'Ayam Goreng',
      price: 25000,
      imageUrl: 'https://i.ibb.co/6yZs2rV/fried-chicken.jpg'),
  MenuItem(
      id: '4',
      name: 'Coca-Cola',
      price: 12000,
      imageUrl: 'https://i.ibb.co/3T4jT7H/cola.jpg'),
];

final List<Order> dummyOrders = [
  Order(
      id: 'ORD-001',
      customerName: 'Andi Pratama',
      items: ['Burger Ayam Crispy', 'Coca-Cola'],
      total: 47000,
      status: 'pending'),
  Order(
      id: 'ORD-002',
      customerName: 'Siti Nurhaliza',
      items: ['Ayam Goreng', 'Kentang Goreng'],
      total: 43000,
      status: 'diproses'),
  Order(
      id: 'ORD-003',
      customerName: 'Budi Santoso',
      items: ['Burger Ayam Crispy'],
      total: 35000,
      status: 'selesai'),
  Order(
      id: 'ORD-004',
      customerName: 'Dewi Lestari',
      items: ['Kentang Goreng', 'Coca-Cola'],
      total: 30000,
      status: 'pending'),
];

final List<InventoryItem> dummyInventoryItems = [
  InventoryItem(
      id: 'INV-1',
      name: 'Daging Ayam',
      unit: 'kg',
      currentStock: 25,
      minStock: 10,
      maxStock: 50),
  InventoryItem(
      id: 'INV-2',
      name: 'Roti Burger',
      unit: 'pcs',
      currentStock: 8,
      minStock: 20,
      maxStock: 100), // Stok Menipis
  InventoryItem(
      id: 'INV-3',
      name: 'Kentang Beku',
      unit: 'kg',
      currentStock: 45,
      minStock: 15,
      maxStock: 60),
  InventoryItem(
      id: 'INV-4',
      name: 'Minyak Goreng',
      unit: 'liter',
      currentStock: 12,
      minStock: 10,
      maxStock: 30),
];

// lib/providers/menu_provider.dart

import 'package:flutter/material.dart';
import '../models/menu_item.dart';
import '../data/dummy_data.dart';

class MenuProvider with ChangeNotifier {
  // _menuItems adalah sumber data utama kita
  List<MenuItem> _menuItems = [];

  List<MenuItem> get menuItems => _menuItems;

  // Method untuk mengambil data awal
  void initializeMenu() {
    _menuItems = List.from(dummyMenuItems);
    notifyListeners(); // Beri tahu semua listener bahwa data sudah siap
  }

  // Method untuk menambah menu
  void addMenu(MenuItem item) {
    _menuItems.add(item);
    notifyListeners(); // Beri tahu semua listener (misalnya HomeScreen dan MenuScreen) untuk rebuild
  }

  // Method untuk memperbarui menu
  void updateMenu(MenuItem updatedItem) {
    final index = _menuItems.indexWhere((item) => item.id == updatedItem.id);
    if (index != -1) {
      _menuItems[index] = updatedItem;
      notifyListeners();
    }
  }

  // Method untuk menghapus menu
  void deleteMenu(String id) {
    _menuItems.removeWhere((item) => item.id == id);
    notifyListeners();
  }

  // Method untuk mengubah ketersediaan
  void toggleAvailability(String id) {
    final item = _menuItems.firstWhere((item) => item.id == id);
    item.isAvailable = !item.isAvailable;
    notifyListeners();
  }
}

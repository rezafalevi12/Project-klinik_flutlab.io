// lib/providers/admin_provider.dart

import 'package:flutter/material.dart';
import '../models/admin_model.dart';

class AdminProvider with ChangeNotifier {
  List<AdminModel> _admins = [];

  List<AdminModel> get admins => _admins;

  void initializeAdmins() {
    _admins = [
      AdminModel(
        id: 1, // Diubah dari '1' menjadi 1
        name: 'Avrio Ridho',
        email: 'avrioridho123@gmail.com',
        phoneNumber: '081994048247',
        role: 'Ketua',
        avatarUrl: '',
      ),
      AdminModel(
        id: 2, // Diubah dari '2' menjadi 2
        name: 'Jonathan K',
        email: 'jonathankarima40@gmail.com',
        phoneNumber: '08223456789',
        role: 'Anggota',
        avatarUrl: '',
      ),
      AdminModel(
        id: 3, // Diubah dari '3' menjadi 3
        name: 'Mohamad Regza Falevi',
        email: 'rezaafalevi12@gmail.com',
        phoneNumber: '08333456789',
        role: 'Anggota',
        avatarUrl: '',
      ),
      AdminModel(
        id: 4, // Diubah dari '4' menjadi 4
        name: 'Ali m Husein',
        email: 'ali@gmail.com',
        phoneNumber: '08443456789',
        role: 'anggota',
        avatarUrl: '',
      ),
      AdminModel(
        id: 5, // Diubah dari '5' menjadi 5
        name: 'M Ardo Nesta',
        email: 'nesta@gmail.com',
        phoneNumber: '08553456789',
        role: 'Anggota',
        avatarUrl: '',
      ),
      AdminModel(
        id: 6, // Diubah dari '6' menjadi 6
        name: 'Rangga S Pratama',
        email: 'Rangga@gmail.com',
        phoneNumber: '08663456789',
        role: 'Anggota',
        avatarUrl: '',
      ),
    ];
    notifyListeners();
  }

  void updateAdmin(AdminModel updatedAdmin) {
    final index = _admins.indexWhere((admin) => admin.id == updatedAdmin.id);
    if (index != -1) {
      _admins[index] = updatedAdmin;
      notifyListeners();
    }
  }
}

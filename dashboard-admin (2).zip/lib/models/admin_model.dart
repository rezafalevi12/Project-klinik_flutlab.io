class AdminModel {
  final int id; // GANTI ke int (sesuai Supabase int8)
  String name;
  String email;
  String phoneNumber;
  String role;
  String avatarUrl;

  AdminModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phoneNumber,
    required this.role,
    required this.avatarUrl,
  });

  /// Dari Supabase → Model
  factory AdminModel.fromMap(Map<String, dynamic> map) {
    return AdminModel(
      id: map['id'],
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phoneNumber: map['phone_number'] ?? '',
      role: map['role'] ?? '',
      avatarUrl: map['avatar_url'] ?? '',
    );
  }

  /// Dari Model → Supabase
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone_number': phoneNumber,
      'role': role,
      'avatar_url': avatarUrl,
    };
  }
}

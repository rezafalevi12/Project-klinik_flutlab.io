import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/admin_model.dart';

class AdminService {
  final _db = Supabase.instance.client;

  /// CREATE
  Future<void> addAdmin(AdminModel admin) async {
    await _db.from('Admin').insert(admin.toMap());
  }

  /// READ
  Future<List<AdminModel>> getAdmins() async {
    final response =
        await _db.from('Admin').select().order('created_at', ascending: false);

    return response.map<AdminModel>((e) => AdminModel.fromMap(e)).toList();
  }

  /// UPDATE
  Future<void> updateAdmin(AdminModel admin) async {
    await _db.from('Admin').update(admin.toMap()).eq('id', admin.id);
  }

  /// DELETE
  Future<void> deleteAdmin(int id) async {
    await _db.from('Admin').delete().eq('id', id);
  }
}
